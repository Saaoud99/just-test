use sdl2::rect::Rect;
use rand::Rng;
pub enum Color {
    Yellow,
    Blue,
    Purple,
}

#[derive(Debug, Clone, Copy)]
pub enum Side {
    Est,
    West,
    North,
    South
}



impl Side {
    pub fn rnd() -> Self {
        let mut rng = rand::thread_rng();
        let r = rng.gen_range(0..=3);
        match r {
            0 => Side::Est,
            1 => Side::West,
            2 => Side::North,
            3 => Side::South,
            _ => unreachable!(),
        }
    }
}

#[derive(Clone)]
pub enum Direction {
    Forward,
    Left,
    Right,
}

#[derive(Clone)]
pub struct Car {
    pub color: String,
    pub direction : Direction,
    pub side : Side,
    pub velocity: i32,
    pub x : i32,
    pub y : i32,
    pub changed : bool,
}


impl Color {
    pub fn to_rgb(&self) -> (u8, u8, u8) {
        match self {
            Color::Yellow => (255, 255, 0),
            Color::Blue => (0, 0, 255),
            Color::Purple => (128, 0, 128),
        }
    }

    pub fn to_string(&self) -> String {
        match self {
            Color::Yellow => "yellow".to_string(),
            Color::Blue => "blue".to_string(),
            Color::Purple => "purple".to_string(),
        }
    }
}


impl Car {
    
    pub fn new(color : String, direction : Direction, side: Side) -> Self {
        let (x, y) = match side {
            Side::Est => (770, 260),
            Side::West => (0, 310),
            Side::North => (360, 6),
            Side::South => (410, 560),
        };
        Car {
            color,
            direction,
            side,
            velocity : 2,
            x,
            y,
            changed:false,
        }
    }

    pub fn collides_in_front(&self, others: &[Car]) -> bool {
        for other in others {
            if !self.is_ahead_of(other) {
                continue;
            }

            if self.lane_overlap(other) && self.distance_to(other) < 35 {
                return true;
            }
        }
        false
    }

    fn is_ahead_of(&self, other: &Car) -> bool {
        match self.side {
            Side::North => other.y > self.y,
            Side::South => other.y < self.y,
            Side::Est => other.x < self.x,
            Side::West => other.x > self.x,
        }
    }

    fn lane_overlap(&self, other: &Car) -> bool {
        match self.side {
            Side::North | Side::South => (self.x - other.x).abs() < 30,
            Side::Est | Side::West => (self.y - other.y).abs() < 30,
        }
    }

    fn distance_to(&self, other: &Car) -> i32 {
        match self.side {
            Side::North | Side::South => (self.y - other.y).abs(),
            Side::Est | Side::West => (self.x - other.x).abs(),
        }
    }

    pub fn movee(&mut self,curr_light : Rect) {
        // println!("{:?}",curr_light);
    use Side::*;
    if !self.changed {
        match (self.color.as_str(), self.side) {
            ("yellow", Side::Est) => {
                if self.x == 410 {
                    self.change_direction(Direction::Right);
                    self.changed = true;
                }
            },
            ("yellow", Side::West) => {
                if self.x == 360{
                    self.change_direction(Direction::Right);
                    self.changed = true;
                }
            },
            ("yellow", Side::North) => {
                if self.y == 260{
                    self.change_direction(Direction::Right);
                    self.changed = true;
                }
            },
            ("yellow", Side::South) => {
                if self.y == 310{
                    self.change_direction(Direction::Right);
                    self.changed = true;
                }
            },
            ("blue", Side::Est) => {
                if self.x == 360{
                    self.change_direction(Direction::Left);
                    self.changed = true;
                }
            },
            ("blue", Side::West) => {
                if self.x == 410{
                    self.change_direction(Direction::Left);
                    self.changed = true;
                }
            },
            ("blue", Side::North) => {
                if self.y == 310{
                    self.change_direction(Direction::Left);
                    self.changed = true;
                }
            },
            ("blue", Side::South) => {
                if self.y == 260{
                    self.change_direction(Direction::Left);
                    self.changed = true;
                }
            },
            _ => {},
        }
    }



    ////////////////
        match self.side {
            Est => {
                if self.x != 452 {

                        self.x -= self.velocity;
                    } else {
                        if curr_light.x == 450 && curr_light.y == 215{   
                            self.x -= self.velocity;
                        }
                    }
                
            },
            West => {
                if self.x != 316 {
                        self.x += self.velocity;
                    } else {
                        if curr_light.x == 315 && curr_light.y == 350{   
                            self.x += self.velocity;
                        }
                    }
                
            },
            North => {
                 if self.y != 218 {
                        self.y += self.velocity;
                    } else {
                        if curr_light.x == 315 && curr_light.y == 215{   
                            self.y += self.velocity;
                        }
                    }
                
            },
            South => {
                    if self.y != 354 {
                        self.y -= self.velocity;
                    } else {
                        if curr_light.x == 450 && curr_light.y == 350{   
                            self.y -= self.velocity;
                        }
                    }
                },
        };
    }
    pub fn change_direction(&mut self, direction : Direction) {
    use Side::*;
    use Direction::*;
        match direction {
            Left => {
                match self.side {
                    Est => {
                        self.side = North;
                    },
                    West => {
                        self.side = South;
                    },
                    North => {
                        self.side = West;
                    },
                    South => {
                        self.side = Est;
                    },
                }
                    },
            Right => {
                match self.side {
                    Est => {
                        self.side = South;
                    },
                    West => {
                        self.side = North;
                    },
                    North => {
                        self.side = Est;
                    },
                    South => {
                        self.side = West;
                    },
                }
            },
            _ => unreachable!(),
        }
    }
}